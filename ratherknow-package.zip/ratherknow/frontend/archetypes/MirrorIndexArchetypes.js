import { useState, useEffect } from 'react';
import { useNavigate, useSearchParams, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import SEO from '../../components/SEO';
import MirrorIndexNav from './MirrorIndexNav';
import MirrorIndexFooter from './MirrorIndexFooter';
import { MI_COLORS, MI_FONTS, ARCHETYPE_CONTENT, ARCHETYPE_ORDER } from './miTheme';
import { MI_SEO, MI_BRAND, breadcrumbJsonLd, MI_KEY_TO_SLUG } from './miSeo';
import { track } from '../../lib/analytics';

export default function MirrorIndexArchetypes() {
  const navigate = useNavigate();
  const [params] = useSearchParams();
  const initialFocus = params.get('focus');
  const [active, setActive] = useState(ARCHETYPE_ORDER.includes(initialFocus) ? initialFocus : 'rock');

  useEffect(() => { track('archetype_viewed', { source: 'mirror_index_archetypes', archetype: active }); }, [active]);

  const a = ARCHETYPE_CONTENT[active];
  const shadowArch = ARCHETYPE_CONTENT[a.shadowArchetype];

  return (
    <div style={{ backgroundColor: MI_COLORS.ivory, fontFamily: MI_FONTS.body, color: MI_COLORS.graphite }} data-testid="mi-archetypes-page">
      <SEO
        {...MI_SEO.archetypes}
        brand={MI_BRAND}
        path="/mirror-index/archetypes"
        jsonLd={breadcrumbJsonLd([{ name: 'Mirror Index', path: '/mirror-index' }, { name: 'The archetypes' }])}
      />
      <MirrorIndexNav />

      {/* Hero */}
      <section className="pt-16 pb-12">
        <div className="max-w-7xl mx-auto px-6 lg:px-12">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 lg:gap-16 items-center">
          <div>
          <p style={{ fontFamily: MI_FONTS.body, fontSize: '12px', fontWeight: 600, letterSpacing: '0.18em', textTransform: 'uppercase', color: MI_COLORS.terracotta, marginBottom: '20px' }}>
            The Six Archetypes
          </p>
          <h1 style={{ fontFamily: MI_FONTS.display, fontWeight: 500, fontSize: 'clamp(40px, 6vw, 60px)', color: MI_COLORS.indigoDeep, letterSpacing: '-0.01em', lineHeight: 1.1, maxWidth: '720px', marginBottom: '20px' }}>
            Each one a gift. Each one a shadow.
          </h1>
          <p style={{ fontFamily: MI_FONTS.body, fontSize: '18px', lineHeight: 1.6, color: MI_COLORS.graphiteSoft, maxWidth: '680px' }}>
            Mirror Index doesn&rsquo;t hand you one archetype and call it a personality. It maps all six — what each offers a partner, where each
            tends to break, who each is quietly drawn to, and who is quietly drawn to you.
          </p>
          </div>
          <figure className="flex justify-center">
            <img
              src="/mirror-index/illus/hexagon_wheel.png"
              alt="The six Mirror Index archetypes — Rock, Challenger, Empath, Voyager, Diplomat and Torchbearer — arranged in a hexagon around a central Mirror Index node."
              data-testid="mi-archetypes-hexagon"
              className="w-full max-w-md"
              style={{ mixBlendMode: 'multiply' }}
            />
          </figure>
          </div>
        </div>
      </section>

      {/* Tab selector */}
      <section className="pb-12">
        <div className="max-w-7xl mx-auto px-6 lg:px-12">
          <div role="tablist" className="grid grid-cols-3 lg:grid-cols-6 gap-2" data-testid="mi-archetypes-tabs">
            {ARCHETYPE_ORDER.map((key) => {
              const ar = ARCHETYPE_CONTENT[key];
              const isActive = active === key;
              return (
                <button
                  key={key}
                  role="tab"
                  aria-selected={isActive}
                  data-testid={`mi-archetype-tab-${key}`}
                  onClick={() => setActive(key)}
                  style={{
                    backgroundColor: isActive ? MI_COLORS.indigoDeep : MI_COLORS.ivoryWarm,
                    color: isActive ? MI_COLORS.ivoryOnDark : MI_COLORS.graphite,
                    border: `1px solid ${isActive ? MI_COLORS.indigoDeep : MI_COLORS.warmGrey}`,
                    fontFamily: MI_FONTS.body,
                    fontSize: '13px',
                    fontWeight: 500,
                    textAlign: 'left',
                    transition: 'all 0.18s ease',
                  }}
                  className="px-4 py-3 rounded-xl"
                >
                  <span style={{ fontFamily: MI_FONTS.display, fontSize: '14px', fontWeight: 600, opacity: 0.7, display: 'block', marginBottom: '4px' }}>{ar.symbol}</span>
                  <span style={{ fontSize: '15px', fontFamily: MI_FONTS.display, fontWeight: 500 }}>{ar.name}</span>
                </button>
              );
            })}
          </div>
        </div>
      </section>

      {/* Archetype detail */}
      <motion.section key={active} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3 }} className="pb-24" data-testid={`mi-archetype-detail-${active}`}>
        <div className="max-w-7xl mx-auto px-6 lg:px-12">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
            {/* Left column — Identity + Self */}
            <div className="lg:col-span-2">
              <div style={{ backgroundColor: MI_COLORS.ivoryWarm, border: `1px solid ${MI_COLORS.warmGrey}` }} className="rounded-3xl p-8 md:p-12 mb-6">
                <div className="flex items-baseline gap-4 mb-4">
                  <span style={{ fontFamily: MI_FONTS.display, fontWeight: 600, fontSize: '24px', color: a.accent }}>{a.symbol}</span>
                  <span style={{ fontFamily: MI_FONTS.body, fontSize: '12px', fontWeight: 600, letterSpacing: '0.14em', textTransform: 'uppercase', color: MI_COLORS.graphiteSoft }}>
                    {a.tagline}
                  </span>
                </div>
                <h2 style={{ fontFamily: MI_FONTS.display, fontWeight: 500, fontSize: 'clamp(40px, 5vw, 56px)', color: MI_COLORS.indigoDeep, letterSpacing: '-0.01em', lineHeight: 1.05, marginBottom: '12px' }}>
                  {a.name}
                </h2>
                <p style={{ fontFamily: MI_FONTS.display, fontSize: '22px', fontStyle: 'italic', color: a.accent, marginBottom: '24px' }} data-testid={`mi-epithet-${active}`}>
                  {a.epithet}
                </p>
                <p style={{ fontFamily: MI_FONTS.body, fontSize: '17px', lineHeight: 1.65, color: MI_COLORS.graphite }}>
                  {a.selfDescription}
                </p>
              </div>

              {/* Shadow side */}
              <div style={{ backgroundColor: MI_COLORS.indigoDeep, color: MI_COLORS.ivoryOnDark }} className="rounded-3xl p-8 md:p-12 mb-6" data-testid={`mi-shadow-side-${active}`}>
                <div className="flex items-center gap-3 mb-5">
                  <span style={{ width: '36px', height: '2px', backgroundColor: MI_COLORS.copper }} />
                  <span style={{ fontFamily: MI_FONTS.body, fontSize: '12px', fontWeight: 600, letterSpacing: '0.18em', textTransform: 'uppercase', color: MI_COLORS.copper }}>
                    The Shadow Side
                  </span>
                </div>
                <p style={{ fontFamily: MI_FONTS.body, fontSize: '17px', lineHeight: 1.7, opacity: 0.92 }}>
                  {a.shadowSide}
                </p>
              </div>

              {/* Behaviours grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div style={{ backgroundColor: MI_COLORS.ivoryWarm, border: `1px solid ${MI_COLORS.warmGrey}` }} className="rounded-2xl p-6">
                  <p style={{ fontFamily: MI_FONTS.body, fontSize: '11px', fontWeight: 600, letterSpacing: '0.16em', textTransform: 'uppercase', color: MI_COLORS.sage, marginBottom: '12px' }}>
                    Green flags in a partner
                  </p>
                  <ul style={{ listStyle: 'none', padding: 0 }}>
                    {a.greenFlags.map((g) => (
                      <li key={g} style={{ fontFamily: MI_FONTS.body, fontSize: '14px', color: MI_COLORS.graphite, padding: '6px 0', borderBottom: `1px solid ${MI_COLORS.warmGrey}` }}>
                        {g}
                      </li>
                    ))}
                  </ul>
                </div>
                <div style={{ backgroundColor: MI_COLORS.ivoryWarm, border: `1px solid ${MI_COLORS.warmGrey}` }} className="rounded-2xl p-6">
                  <p style={{ fontFamily: MI_FONTS.body, fontSize: '11px', fontWeight: 600, letterSpacing: '0.16em', textTransform: 'uppercase', color: MI_COLORS.copper, marginBottom: '12px' }}>
                    How love lands
                  </p>
                  <p style={{ fontFamily: MI_FONTS.display, fontSize: '18px', fontWeight: 500, color: MI_COLORS.indigoDeep, lineHeight: 1.4, marginBottom: '20px' }} data-testid={`mi-how-love-lands-${active}`}>{a.howLoveLands}</p>
                  <p style={{ fontFamily: MI_FONTS.body, fontSize: '11px', fontWeight: 600, letterSpacing: '0.16em', textTransform: 'uppercase', color: MI_COLORS.copper, marginBottom: '12px' }}>
                    Ideal partner
                  </p>
                  <p style={{ fontFamily: MI_FONTS.body, fontSize: '14px', color: MI_COLORS.graphite, lineHeight: 1.55 }}>{a.idealPartner}</p>
                </div>
              </div>
            </div>

            {/* Right column — Shadow archetype mapping */}
            <div className="lg:col-span-1">
              <div style={{ position: 'sticky', top: '92px' }}>
                <figure className="mb-6 mx-auto" style={{ maxWidth: '230px' }} data-testid={`mi-archetype-card-${active}`}>
                  <img
                    src={`/mirror-index/cards/${active}.png`}
                    alt={`${a.name} — Mirror Index archetype share card`}
                    className="w-full rounded-2xl"
                    style={{ border: `1px solid ${MI_COLORS.warmGrey}`, boxShadow: '0 16px 40px -22px rgba(30,42,71,0.5)' }}
                  />
                  <a
                    href={`/mirror-index/cards/${active}.png`}
                    download={`mirror-index-${active}.png`}
                    data-testid={`mi-archetype-card-download-${active}`}
                    style={{ fontFamily: MI_FONTS.body, fontSize: '12px', fontWeight: 600, color: MI_COLORS.copper }}
                    className="block text-center mt-2.5 hover:underline"
                  >
                    Download this card &darr;
                  </a>
                </figure>
                <Link
                  to={`/mirror-index/archetypes/${MI_KEY_TO_SLUG[active]}`}
                  data-testid={`mi-archetype-fullprofile-${active}`}
                  style={{ display: 'block', textAlign: 'center', fontFamily: MI_FONTS.body, fontSize: '13px', fontWeight: 600, color: MI_COLORS.indigoDeep, borderBottom: `1px solid ${MI_COLORS.warmGrey}`, paddingBottom: '18px', marginBottom: '22px' }}
                  className="hover:opacity-70 transition-opacity"
                >
                  Read the full {a.name} profile →
                </Link>
                <p style={{ fontFamily: MI_FONTS.body, fontSize: '11px', fontWeight: 600, letterSpacing: '0.18em', textTransform: 'uppercase', color: MI_COLORS.terracotta, marginBottom: '16px' }}>
                  Shadow Attraction Map
                </p>
                <div style={{ backgroundColor: '#fff', border: `2px solid ${MI_COLORS.terracotta}` }} className="rounded-3xl p-7" data-testid={`mi-shadow-map-${active}`}>
                  <div style={{ fontFamily: MI_FONTS.body, fontSize: '13px', color: MI_COLORS.graphiteSoft, marginBottom: '10px' }}>
                    {a.name} is unconsciously drawn to
                  </div>
                  <p style={{ fontFamily: MI_FONTS.display, fontWeight: 500, fontSize: '36px', color: shadowArch.accent, letterSpacing: '-0.01em', lineHeight: 1, marginBottom: '4px' }}>
                    {shadowArch.name}
                  </p>
                  <p style={{ fontFamily: MI_FONTS.body, fontSize: '11px', fontWeight: 600, letterSpacing: '0.14em', textTransform: 'uppercase', color: MI_COLORS.graphiteSoft, marginBottom: '20px' }}>
                    {shadowArch.tagline}
                  </p>
                  <p style={{ fontFamily: MI_FONTS.body, fontSize: '14px', lineHeight: 1.65, color: MI_COLORS.graphite }}>
                    {a.shadowArchetypeNote}
                  </p>
                </div>

                {/* Who's drawn to you */}
                <div style={{ backgroundColor: MI_COLORS.ivoryWarm, border: `1px solid ${MI_COLORS.warmGrey}` }} className="rounded-3xl p-7 mt-4" data-testid={`mi-drawn-to-you-${active}`}>
                  <p style={{ fontFamily: MI_FONTS.body, fontSize: '11px', fontWeight: 600, letterSpacing: '0.16em', textTransform: 'uppercase', color: MI_COLORS.sage, marginBottom: '10px' }}>
                    Who&rsquo;s drawn to you
                  </p>
                  <p style={{ fontFamily: MI_FONTS.body, fontSize: '14px', lineHeight: 1.65, color: MI_COLORS.graphite }}>
                    {a.drawnToYou}
                  </p>
                </div>

                <button
                  data-testid="mi-archetypes-quiz-btn"
                  onClick={() => navigate('/mirror-index/quiz-select')}
                  style={{ backgroundColor: MI_COLORS.copper, color: '#fff', fontFamily: MI_FONTS.body, fontSize: '14px', fontWeight: 500, marginTop: '16px' }}
                  className="w-full px-5 py-3.5 rounded-full hover:opacity-90 transition-opacity"
                >
                  Meet your archetype — free →
                </button>

                <p style={{ fontFamily: MI_FONTS.body, fontSize: '11px', color: MI_COLORS.graphiteSoft, textAlign: 'center', marginTop: '12px', lineHeight: 1.5 }}>
                  12 minutes · Self lens included free
                </p>
              </div>
            </div>
          </div>
        </div>
      </motion.section>

      {/* Shadow pairings overview */}
      <section style={{ backgroundColor: MI_COLORS.ivoryWarm, borderTop: `1px solid ${MI_COLORS.warmGrey}` }} className="py-20" data-testid="mi-shadow-pairings">
        <div className="max-w-7xl mx-auto px-6 lg:px-12">
          <p style={{ fontFamily: MI_FONTS.body, fontSize: '12px', fontWeight: 600, letterSpacing: '0.18em', textTransform: 'uppercase', color: MI_COLORS.terracotta, marginBottom: '16px' }}>
            The full map
          </p>
          <h2 style={{ fontFamily: MI_FONTS.display, fontWeight: 500, fontSize: 'clamp(28px, 3.5vw, 40px)', color: MI_COLORS.indigoDeep, letterSpacing: '-0.01em', maxWidth: '640px', marginBottom: '32px' }}>
            Every archetype, the partner-type it unconsciously chases.
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {ARCHETYPE_ORDER.map((key) => {
              const ar = ARCHETYPE_CONTENT[key];
              const sh = ARCHETYPE_CONTENT[ar.shadowArchetype];
              return (
                <button
                  key={key}
                  data-testid={`mi-shadow-pair-${key}`}
                  onClick={() => setActive(key)}
                  style={{ backgroundColor: '#fff', border: `1px solid ${MI_COLORS.warmGrey}` }}
                  className="rounded-2xl p-5 text-left hover:shadow-md transition-shadow"
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <p style={{ fontFamily: MI_FONTS.display, fontSize: '20px', fontWeight: 500, color: ar.accent }}>{ar.name}</p>
                      <p style={{ fontFamily: MI_FONTS.body, fontSize: '11px', letterSpacing: '0.1em', textTransform: 'uppercase', color: MI_COLORS.graphiteSoft }}>chases</p>
                    </div>
                    <span style={{ fontSize: '24px', color: MI_COLORS.copper, fontFamily: MI_FONTS.display }}>→</span>
                    <p style={{ fontFamily: MI_FONTS.display, fontSize: '20px', fontWeight: 500, color: sh.accent }}>{sh.name}</p>
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      </section>

      <MirrorIndexFooter />
    </div>
  );
}
