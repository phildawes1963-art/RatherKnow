import { Link, useNavigate } from 'react-router-dom';
import { useEffect, useState } from 'react';
import { MI_COLORS, MI_FONTS } from './miTheme';
import { useAuth } from '../../contexts/DWAuthContext';

const linkStyle = { color: MI_COLORS.graphiteSoft, fontFamily: MI_FONTS.body, fontSize: '15px' };

export default function MirrorIndexNav() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8);
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <nav
      data-testid="mi-nav"
      style={{
        backgroundColor: scrolled ? 'rgba(250, 246, 240, 0.92)' : MI_COLORS.ivory,
        borderBottom: `1px solid ${MI_COLORS.warmGrey}`,
        backdropFilter: 'blur(10px)',
      }}
      className="sticky top-0 z-40"
    >
      <div className="max-w-7xl mx-auto px-6 lg:px-12 py-5 flex items-center justify-between">
        <Link to="/mirror-index" className="flex items-baseline gap-2" data-testid="mi-logo">
          <span style={{ fontFamily: MI_FONTS.display, fontWeight: 600, fontSize: '24px', color: MI_COLORS.indigoDeep, letterSpacing: '-0.01em' }}>
            Mirror Index
          </span>
          <span style={{ fontFamily: MI_FONTS.body, fontSize: '11px', color: MI_COLORS.graphiteSoft, textTransform: 'uppercase', letterSpacing: '0.1em' }}>
            by My Mirror Report
          </span>
        </Link>

        <div className="hidden lg:flex items-center gap-7">
          <Link to="/mirror-index/archetypes" style={linkStyle} className="hover:opacity-70 transition-opacity" data-testid="mi-nav-archetypes">Archetypes</Link>
          <Link to="/mirror-index/how-it-works" style={linkStyle} className="hover:opacity-70 transition-opacity" data-testid="mi-nav-how">How it works</Link>
          <Link to="/mirror-index/reports" style={linkStyle} className="hover:opacity-70 transition-opacity" data-testid="mi-nav-reports">The Reports</Link>
          <Link to="/mirror-index/learn" style={linkStyle} className="hover:opacity-70 transition-opacity" data-testid="mi-nav-learn">Learn</Link>
          <Link to="/mirror-index/about" style={linkStyle} className="hover:opacity-70 transition-opacity" data-testid="mi-nav-about">About</Link>
          <Link to="/mirror-index/pricing" style={linkStyle} className="hover:opacity-70 transition-opacity" data-testid="mi-nav-pricing">Pricing</Link>
        </div>

        <div className="flex items-center gap-3">
          {user ? (
            <button
              data-testid="mi-nav-dashboard-btn"
              onClick={() => navigate('/mirror-index/dashboard')}
              style={{ backgroundColor: MI_COLORS.indigoDeep, color: MI_COLORS.ivoryOnDark, fontFamily: MI_FONTS.body, fontSize: '14px', fontWeight: 500 }}
              className="px-5 py-2.5 rounded-full hover:opacity-90 transition-opacity"
            >
              My dashboard
            </button>
          ) : (
            <>
              <button
                data-testid="mi-nav-signin-btn"
                onClick={() => navigate('/mirror-index/login')}
                style={{ color: MI_COLORS.graphite, fontFamily: MI_FONTS.body, fontSize: '14px' }}
                className="hidden sm:block hover:opacity-70"
              >
                Sign in
              </button>
              <button
                data-testid="mi-nav-start-btn"
                onClick={() => navigate('/mirror-index/quiz-select')}
                style={{ backgroundColor: MI_COLORS.indigoDeep, color: MI_COLORS.ivoryOnDark, fontFamily: MI_FONTS.body, fontSize: '14px', fontWeight: 500 }}
                className="px-5 py-2.5 rounded-full hover:opacity-90 transition-opacity inline-flex items-center gap-1.5"
              >
                Get started <span aria-hidden>→</span>
              </button>
            </>
          )}
        </div>
      </div>
    </nav>
  );
}
