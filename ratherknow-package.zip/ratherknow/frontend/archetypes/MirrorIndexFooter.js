import { Link } from 'react-router-dom';
import { MI_COLORS, MI_FONTS } from './miTheme';

const colHead = { fontFamily: MI_FONTS.body, fontSize: '12px', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.12em', color: MI_COLORS.ivoryOnDark, opacity: 0.7, marginBottom: '16px' };
const linkS = { fontFamily: MI_FONTS.body, fontSize: '14px', color: MI_COLORS.ivoryOnDark, opacity: 0.85, display: 'block', marginBottom: '10px' };

export default function MirrorIndexFooter() {
  return (
    <footer style={{ backgroundColor: MI_COLORS.indigoDeep, color: MI_COLORS.ivoryOnDark }} data-testid="mi-footer">
      <div className="max-w-7xl mx-auto px-6 lg:px-12 py-16">
        <div className="grid grid-cols-2 md:grid-cols-5 gap-10">
          <div className="col-span-2">
            <p style={{ fontFamily: MI_FONTS.display, fontWeight: 500, fontSize: '28px', letterSpacing: '-0.01em' }}>Mirror Index</p>
            <p style={{ fontFamily: MI_FONTS.body, fontSize: '14px', opacity: 0.7, maxWidth: '320px', marginTop: '12px', lineHeight: 1.6 }}>
              A professional-grade relationship assessment. Six archetypes, two lenses, one honest map of who you are and who you actually need.
            </p>
            <p style={{ fontFamily: MI_FONTS.body, fontSize: '12px', opacity: 0.5, marginTop: '20px' }}>
              A product of My Mirror Report Ltd · Registered in England
            </p>
          </div>

          <div>
            <p style={colHead}>Product</p>
            <Link to="/mirror-index/archetypes" style={linkS}>Archetypes</Link>
            <Link to="/mirror-index/how-it-works" style={linkS}>How it works</Link>
            <Link to="/mirror-index/reports" style={linkS}>The Reports</Link>
            <Link to="/mirror-index/learn" style={linkS}>Learn</Link>
            <Link to="/mirror-index/pricing" style={linkS}>Pricing</Link>
          </div>

          <div>
            <p style={colHead}>Company</p>
            <Link to="/mirror-index/why" style={linkS}>Why Mirror Index</Link>
            <Link to="/mirror-index/philosophy" style={linkS}>Our philosophy</Link>
            <Link to="/mirror-index/science" style={linkS}>The science</Link>
            <Link to="/mirror-index/about" style={linkS}>About</Link>
            <Link to="/mirror-index/faq" style={linkS}>FAQ</Link>
          </div>

          <div>
            <p style={colHead}>Business</p>
            <Link to="/contact-us" style={linkS}>Contact</Link>
            <Link to="/" style={linkS}>Parent brand</Link>
            <p style={colHead} className="mt-6">Legal</p>
            <Link to="/privacy-policy" style={linkS}>Privacy</Link>
            <Link to="/terms-of-service" style={linkS}>Terms</Link>
          </div>
        </div>

        <div style={{ borderTop: `1px solid ${MI_COLORS.indigoSoft}`, marginTop: '40px', paddingTop: '24px' }} className="flex flex-col md:flex-row md:items-center md:justify-between gap-3">
          <p style={{ fontFamily: MI_FONTS.body, fontSize: '12px', opacity: 0.5 }}>
            © {new Date().getFullYear()} My Mirror Report Ltd. All rights reserved.
          </p>
          <p style={{ fontFamily: MI_FONTS.body, fontSize: '12px', opacity: 0.5, maxWidth: '520px', textAlign: 'right' }} data-testid="mi-disclaimer">
            Mirror Index is a self-reflection tool, not a clinical diagnostic. Not intended for use as a pre-employment screen, medical diagnosis or therapy substitute.
          </p>
        </div>
      </div>
    </footer>
  );
}
