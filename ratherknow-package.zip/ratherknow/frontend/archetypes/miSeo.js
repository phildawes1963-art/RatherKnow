// Centralised Mirror Index SEO payload (source: seo-payload.json v1.0, 17 Jul 2026).
// Wired client-side via react-helmet today; ports directly to the Next.js/T1
// server-rendered pass. Titles ≤60 chars, descriptions ≤155, brand = "Mirror Index".
export const MI_BASE = 'https://mymirrorreport.com';
export const MI_BRAND = 'Mirror Index';

// ---- JSON-LD helpers -------------------------------------------------------
export const orgJsonLd = {
  '@context': 'https://schema.org',
  '@type': 'Organization',
  name: 'Mirror Index',
  url: `${MI_BASE}/mirror-index`,
  logo: `${MI_BASE}/mirror-index/og/logo.png`,
  parentOrganization: { '@type': 'Organization', name: 'My Mirror Report Ltd' },
};

export const breadcrumbJsonLd = (crumbs) => ({
  '@context': 'https://schema.org',
  '@type': 'BreadcrumbList',
  itemListElement: crumbs.map((c, i) => ({
    '@type': 'ListItem',
    position: i + 1,
    name: c.name,
    ...(c.path ? { item: `${MI_BASE}${c.path}` } : {}),
  })),
});

export const articleJsonLd = ({ headline, description, path, image }) => ({
  '@context': 'https://schema.org',
  '@type': 'Article',
  headline,
  description,
  image: `${MI_BASE}${image || '/og/default.png'}`,
  author: { '@type': 'Organization', name: 'Mirror Index' },
  publisher: { '@type': 'Organization', name: 'Mirror Index' },
  mainEntityOfPage: `${MI_BASE}${path}`,
});

export const faqJsonLd = (qas) => ({
  '@context': 'https://schema.org',
  '@type': 'FAQPage',
  mainEntity: qas.map((q) => ({
    '@type': 'Question',
    name: q.q,
    acceptedAnswer: { '@type': 'Answer', text: q.a },
  })),
});

export const productJsonLd = {
  '@context': 'https://schema.org',
  '@type': 'Product',
  name: 'Mirror Index Relationship Assessment',
  description: 'Six-archetype, two-lens relationship self-assessment with shadow analysis.',
  brand: { '@type': 'Brand', name: 'Mirror Index' },
  offers: [
    { '@type': 'Offer', name: 'Free Mirror', price: '0', priceCurrency: 'GBP' },
    { '@type': 'Offer', name: 'Mirror Report', price: '19.00', priceCurrency: 'GBP' },
    { '@type': 'Offer', name: 'Full Mirror', price: '34.00', priceCurrency: 'GBP' },
    { '@type': 'Offer', name: 'Complete Me', price: '59.00', priceCurrency: 'GBP' },
  ],
};

// ---- Per-page title / description (verbatim from the payload) --------------
export const MI_SEO = {
  home: {
    title: 'Mirror Index | Relationship Assessment for Intentional Dating',
    description: 'Six archetypes, two lenses, one honest read. Discover who you are as a partner, who you keep choosing, and why it stops working. Free to start.',
    ogType: 'website',
  },
  archetypes: {
    title: 'The Six Relationship Archetypes | Mirror Index',
    description: "The Rock, The Challenger, The Empath, The Voyager, The Diplomat, The Torchbearer — each with a gift, a shadow, and a type it can't resist. Find yours.",
    ogType: 'website',
  },
  howItWorks: {
    title: 'How It Works — 50 Questions, Two Lenses, One Delta | Mirror Index',
    description: 'Twelve minutes. Fifty questions answered twice — once as who you are, once as who you want. How the Delta, the shadow map and the Cross-Check work.',
    ogType: 'website',
  },
  reports: {
    title: 'Sample Reports & The Audio Mirror | Mirror Index',
    description: 'Read full-length sample reports and hear the Audio Mirror — professional third-person narration of a demonstration profile. See what you get before you pay.',
    ogType: 'website',
  },
  pricing: {
    title: 'Pricing — Start Free, Choose Your Depth | Mirror Index',
    description: 'One free archetype read. Three paid depths from £19, all with a 30-day money-back guarantee. No subscription, no card to start.',
    ogType: 'website',
  },
  why: {
    title: 'Why Mirror Index? Not a Dating App, Not a Quiz',
    description: 'Dating apps optimise for matches. Quizzes optimise for flattery. Mirror Index optimises for you choosing better — including when not to buy it.',
    ogType: 'website',
  },
  philosophy: {
    title: 'Our Philosophy — Never a Verdict | Mirror Index',
    description: 'We believe an assessment is a serious conversation starter, not an answer. Why Mirror Index is written to be argued with — and what we refuse to claim.',
    ogType: 'article',
  },
  about: {
    title: "About — Who's Behind the Mirror | Mirror Index",
    description: 'Built by a psychometrician who spent twenty years measuring people for boardrooms — and wondered why love only got magazine quizzes. The story and the promise.',
    ogType: 'website',
  },
  science: {
    title: 'The Science — Validity, Reliability, Honest Limits | Mirror Index',
    description: "Where every Mirror Index instrument sits on our evidence ladder: what's validated, what's still maturing, and the numbers we publish either way.",
    ogType: 'article',
  },
  postBreakup: {
    title: 'Why You Keep Choosing the Wrong Partner | Mirror Index',
    description: "The relationship ended. The pattern didn't. Map the type you keep choosing — and the shadow pull behind it — before you date again. Free to start.",
    ogType: 'article',
  },
  forCoaches: {
    title: 'Mirror Index for Coaches — A Conversation-Starting Assessment',
    description: 'An intake instrument built on the belief that assessments start conversations, not end them. Reports, practitioner view, and pilot pricing for coaches.',
    ogType: 'website',
  },
  faq: {
    title: 'FAQ | Mirror Index',
    description: "Is it accurate? Is it a dating app? Can couples take it? What happens to my data? Every question we're asked, answered plainly.",
    ogType: 'website',
  },
  learn: {
    title: 'Learn — The Pattern, Named | Mirror Index',
    description: 'Short, honest essays on why capable people keep choosing the wrong partner — and what actually shifts it. No red-flag listicles, just the mechanism.',
    ogType: 'website',
  },
};

// ---- Archetype detail pages -----------------------------------------------
export const MI_KEY_TO_SLUG = {
  rock: 'the-rock',
  challenger: 'the-challenger',
  empath: 'the-empath',
  adventurer: 'the-voyager',
  diplomat: 'the-diplomat',
  visionary: 'the-torchbearer',
};
export const MI_SLUG_TO_KEY = Object.fromEntries(Object.entries(MI_KEY_TO_SLUG).map(([k, v]) => [v, k]));
export const MI_ARCHETYPE_SLUGS = Object.values(MI_KEY_TO_SLUG);
export const cardUrl = (key) => `/mirror-index/cards/${key}.png`;

export const MI_ARCHETYPE_SEO = {
  'the-rock': {
    title: 'The Rock — Relationship Archetype | Mirror Index',
    description: 'Loyal, steady, the safe harbour — and secretly drawn to the Empath who unsettles it all. The Rock archetype honestly told: gifts, shadow, green flags.',
    h1: 'The Rock — Stability & Tradition',
  },
  'the-challenger': {
    title: 'The Challenger — Relationship Archetype | Mirror Index',
    description: "Growth as devotion — and a weakness for partners who won't argue back. The Challenger archetype: gifts, shadow, and who is quietly drawn to you.",
    h1: 'The Challenger — Intellect & Growth',
  },
  'the-empath': {
    title: 'The Empath — Relationship Archetype | Mirror Index',
    description: 'Feels the room before it speaks — and falls for the one who makes feeling seem like too much. The Empath archetype: gifts, shadow, green flags.',
    h1: 'The Empath — Connection & Intimacy',
  },
  'the-voyager': {
    title: 'The Voyager — Relationship Archetype | Mirror Index',
    description: 'Turns ordinary days into stories — then falls for stability and calls it home until it feels like a schedule. The Voyager archetype, honestly told.',
    h1: 'The Voyager — Social & Lifestyle',
  },
  'the-diplomat': {
    title: 'The Diplomat — Relationship Archetype | Mirror Index',
    description: 'Says the hard thing gently — and is drawn to the certainty that mistakes gentleness for weakness. The Diplomat archetype: gifts, shadow, green flags.',
    h1: 'The Diplomat — Harmony & Communication',
  },
  'the-torchbearer': {
    title: 'The Torchbearer — Relationship Archetype | Mirror Index',
    description: 'Love in service of a bigger arc — and a shadow-pull toward the practical partner who prices the dream. The Torchbearer archetype, honestly told.',
    h1: 'The Torchbearer — Purpose & Ambition',
  },
};
