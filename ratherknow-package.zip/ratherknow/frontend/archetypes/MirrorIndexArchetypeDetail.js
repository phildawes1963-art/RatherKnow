import { useParams, Link, Navigate } from 'react-router-dom';
import SEO from '../../components/SEO';
import MirrorIndexNav from './MirrorIndexNav';
import MirrorIndexFooter from './MirrorIndexFooter';
import { MI_COLORS, MI_FONTS, ARCHETYPE_CONTENT, ARCHETYPE_ORDER } from './miTheme';
import { CTA } from './miUi';
import {
  MI_SLUG_TO_KEY,
  MI_KEY_TO_SLUG,
  MI_ARCHETYPE_SEO,
  MI_BRAND,
  cardUrl,
  breadcrumbJsonLd,
  articleJsonLd,
} from './miSeo';

const linkS = { color: MI_COLORS.indigoDeep, borderBottom: `1px solid ${MI_COLORS.indigoDeep}` };

function SectionTitle({ children }) {
  return (
    <h2 style={{ fontFamily: MI_FONTS.display, fontSize: 'clamp(24px, 3.2vw, 32px)', fontWeight: 500, color: MI_COLORS.indigoDeep, letterSpacing: '-0.01em', marginBottom: '14px' }}>
      {children}
    </h2>
  );
}

export default function MirrorIndexArchetypeDetail() {
  const { slug } = useParams();
  const key = MI_SLUG_TO_KEY[slug];
  if (!key) return <Navigate to="/mirror-index/archetypes" replace />;

  const a = ARCHETYPE_CONTENT[key];
  const seo = MI_ARCHETYPE_SEO[slug];
  const shadow = ARCHETYPE_CONTENT[a.shadowArchetype];
  const others = ARCHETYPE_ORDER.filter((k) => k !== key);

  return (
    <div style={{ backgroundColor: MI_COLORS.ivory, fontFamily: MI_FONTS.body, color: MI_COLORS.graphite }} data-testid={`mi-archetype-detail-${slug}`}>
      <SEO
        {...seo}
        brand={MI_BRAND}
        path={`/mirror-index/archetypes/${slug}`}
        ogImage={cardUrl(key)}
        ogType="article"
        jsonLd={[
          breadcrumbJsonLd([
            { name: 'Mirror Index', path: '/mirror-index' },
            { name: 'The archetypes', path: '/mirror-index/archetypes' },
            { name: a.name },
          ]),
          articleJsonLd({ headline: seo.h1, description: seo.description, path: `/mirror-index/archetypes/${slug}`, image: cardUrl(key) }),
        ]}
      />
      <MirrorIndexNav />

      {/* Breadcrumb */}
      <div className="max-w-6xl mx-auto px-6 lg:px-12 pt-6">
        <p style={{ fontFamily: MI_FONTS.body, fontSize: '13px', color: MI_COLORS.graphiteSoft }}>
          <Link to="/mirror-index/archetypes" style={{ color: MI_COLORS.graphiteSoft }} className="hover:underline">The archetypes</Link>
          <span style={{ margin: '0 8px' }}>/</span>
          <span style={{ color: MI_COLORS.indigoDeep }}>{a.name}</span>
        </p>
      </div>

      {/* Hero */}
      <section className="pt-8 pb-14">
        <div className="max-w-6xl mx-auto px-6 lg:px-12 grid grid-cols-1 lg:grid-cols-3 gap-10 lg:gap-16 items-start">
          <div className="lg:col-span-2">
            <div className="flex items-center gap-4 mb-5">
              <span style={{ fontFamily: MI_FONTS.display, fontSize: '30px', fontWeight: 500, color: a.accent }}>{a.symbol}</span>
              <span style={{ fontFamily: MI_FONTS.body, fontSize: '12px', fontWeight: 600, letterSpacing: '0.18em', textTransform: 'uppercase', color: MI_COLORS.copper }}>{a.tagline}</span>
            </div>
            <h1 data-testid="mi-page-h1" style={{ fontFamily: MI_FONTS.display, fontWeight: 500, fontSize: 'clamp(38px, 6vw, 56px)', color: MI_COLORS.indigoDeep, letterSpacing: '-0.01em', lineHeight: 1.05, marginBottom: '16px' }}>
              {seo.h1}
            </h1>
            <p style={{ fontFamily: MI_FONTS.display, fontStyle: 'italic', fontSize: '22px', color: MI_COLORS.copper, marginBottom: '20px' }}>{a.epithet}</p>
            <p style={{ fontFamily: MI_FONTS.body, fontSize: '18px', lineHeight: 1.7, color: MI_COLORS.graphiteSoft }}>{a.selfDescription}</p>
          </div>

          <figure className="mx-auto lg:mx-0" style={{ maxWidth: '260px' }} data-testid="mi-detail-card">
            <img
              src={cardUrl(key)}
              alt={`${a.name} — Mirror Index archetype card`}
              className="w-full rounded-2xl"
              style={{ border: `1px solid ${MI_COLORS.warmGrey}`, boxShadow: '0 18px 44px -24px rgba(30,42,71,0.5)' }}
            />
            <a href={cardUrl(key)} download={`mirror-index-${key}.png`} data-testid="mi-detail-card-download" style={{ fontFamily: MI_FONTS.body, fontSize: '12px', fontWeight: 600, color: MI_COLORS.copper }} className="block text-center mt-2.5 hover:underline">
              Download this card &darr;
            </a>
          </figure>
        </div>
      </section>

      {/* Body */}
      <section className="pb-8">
        <div className="max-w-3xl mx-auto px-6 lg:px-12 space-y-14">
          <div>
            <SectionTitle>How love lands</SectionTitle>
            <p style={{ fontFamily: MI_FONTS.body, fontSize: '17px', lineHeight: 1.7, color: MI_COLORS.graphiteSoft }}>{a.howLoveLands}</p>
          </div>

          <div>
            <SectionTitle>Green flags to look for</SectionTitle>
            <ul className="space-y-2">
              {a.greenFlags.map((g) => (
                <li key={g} className="flex items-start gap-3" style={{ fontFamily: MI_FONTS.body, fontSize: '17px', color: MI_COLORS.graphite }}>
                  <span style={{ color: MI_COLORS.sage, fontWeight: 700 }} aria-hidden>✓</span> {g}
                </li>
              ))}
            </ul>
          </div>

          <div>
            <SectionTitle>The shadow</SectionTitle>
            <p style={{ fontFamily: MI_FONTS.body, fontSize: '17px', lineHeight: 1.7, color: MI_COLORS.graphiteSoft, marginBottom: '18px' }}>{a.shadowSide}</p>
          </div>
        </div>
      </section>

      {/* Shadow attraction — dark band */}
      <section className="py-16" style={{ backgroundColor: MI_COLORS.indigoDeep, color: MI_COLORS.ivoryOnDark }} data-testid="mi-detail-shadow">
        <div className="max-w-3xl mx-auto px-6 lg:px-12">
          <p style={{ fontFamily: MI_FONTS.body, fontSize: '12px', fontWeight: 600, letterSpacing: '0.18em', textTransform: 'uppercase', color: MI_COLORS.copper, marginBottom: '18px' }}>
            Secretly drawn to
          </p>
          <h2 style={{ fontFamily: MI_FONTS.display, fontSize: 'clamp(26px, 4vw, 36px)', fontWeight: 500, marginBottom: '14px' }}>{shadow.name}</h2>
          <p style={{ fontFamily: MI_FONTS.body, fontSize: '17px', lineHeight: 1.7, opacity: 0.9, marginBottom: '20px' }}>{a.shadowArchetypeNote}</p>
          <Link to={`/mirror-index/archetypes/${MI_KEY_TO_SLUG[a.shadowArchetype]}`} style={{ color: MI_COLORS.ivoryOnDark, borderBottom: `1px solid ${MI_COLORS.copper}` }} className="text-sm">
            Read about {shadow.name} →
          </Link>
        </div>
      </section>

      {/* Drawn to you + ideal partner */}
      <section className="py-16">
        <div className="max-w-3xl mx-auto px-6 lg:px-12 space-y-14">
          <div>
            <SectionTitle>Who’s drawn to you</SectionTitle>
            <p style={{ fontFamily: MI_FONTS.body, fontSize: '17px', lineHeight: 1.7, color: MI_COLORS.graphiteSoft }}>{a.drawnToYou}</p>
          </div>
          <div>
            <SectionTitle>Your ideal partner</SectionTitle>
            <p style={{ fontFamily: MI_FONTS.body, fontSize: '17px', lineHeight: 1.7, color: MI_COLORS.graphiteSoft }}>{a.idealPartner}</p>
          </div>

          {/* Cross-links */}
          <div>
            <p style={{ fontFamily: MI_FONTS.body, fontSize: '12px', fontWeight: 600, letterSpacing: '0.18em', textTransform: 'uppercase', color: MI_COLORS.copper, marginBottom: '14px' }}>
              The other five
            </p>
            <div className="flex flex-wrap gap-2" data-testid="mi-detail-crosslinks">
              {others.map((k) => (
                <Link
                  key={k}
                  to={`/mirror-index/archetypes/${MI_KEY_TO_SLUG[k]}`}
                  style={{ border: `1px solid ${MI_COLORS.warmGrey}`, backgroundColor: MI_COLORS.ivoryWarm, color: MI_COLORS.indigoDeep, fontFamily: MI_FONTS.body, fontSize: '14px' }}
                  className="px-4 py-2 rounded-full hover:opacity-80 transition-opacity"
                >
                  {ARCHETYPE_CONTENT[k].name}
                </Link>
              ))}
            </div>
          </div>

          <CTA
            title={`Are you really ${a.name}?`}
            sub="Take the free read and find out which archetype you actually are — and which one you keep choosing."
            label="Find your archetype — free"
            testid="mi-detail-cta"
          />
        </div>
      </section>

      <MirrorIndexFooter />
    </div>
  );
}
