import { Link } from 'react-router-dom';
import { MI_COLORS, MI_FONTS } from './miTheme';

export const Eyebrow = ({ children, color = MI_COLORS.copper }) => (
  <p style={{ fontFamily: MI_FONTS.body, fontSize: '12px', fontWeight: 600, letterSpacing: '0.18em', textTransform: 'uppercase', color, marginBottom: '20px' }}>
    {children}
  </p>
);

export const PageHero = ({ eyebrow, title, sub, testid = 'mi-page-hero' }) => (
  <section className="pt-16 pb-12" data-testid={testid}>
    <div className="max-w-4xl mx-auto px-6 lg:px-12">
      {eyebrow && <Eyebrow>{eyebrow}</Eyebrow>}
      <h1
        data-testid="mi-page-h1"
        style={{ fontFamily: MI_FONTS.display, fontWeight: 500, fontSize: 'clamp(38px, 6vw, 58px)', color: MI_COLORS.indigoDeep, letterSpacing: '-0.01em', lineHeight: 1.05, marginBottom: '24px' }}
      >
        {title}
      </h1>
      {sub && (
        <p style={{ fontFamily: MI_FONTS.body, fontSize: '19px', lineHeight: 1.6, color: MI_COLORS.graphiteSoft, maxWidth: '720px' }}>
          {sub}
        </p>
      )}
    </div>
  </section>
);

export const Block = ({ title, children }) => (
  <div>
    <div style={{ width: '40px', height: '2px', backgroundColor: MI_COLORS.copper, marginBottom: '16px' }} />
    {title && (
      <h2 style={{ fontFamily: MI_FONTS.display, fontSize: 'clamp(24px, 3.2vw, 34px)', fontWeight: 500, color: MI_COLORS.indigoDeep, letterSpacing: '-0.01em', marginBottom: '16px', lineHeight: 1.15 }}>
        {title}
      </h2>
    )}
    <div style={{ fontFamily: MI_FONTS.body, fontSize: '17px', lineHeight: 1.7, color: MI_COLORS.graphiteSoft }}>
      {children}
    </div>
  </div>
);

export const Lead = ({ children }) => (
  <span style={{ color: MI_COLORS.indigoDeep, fontWeight: 600 }}>{children}</span>
);

export const CTA = ({
  title,
  sub,
  to = '/mirror-index/quiz-select',
  label = 'Start free',
  testid = 'mi-page-cta',
}) => (
  <div style={{ backgroundColor: MI_COLORS.ivoryWarm, border: `1px solid ${MI_COLORS.warmGrey}` }} className="rounded-3xl p-10 mt-16 text-center">
    <h3 style={{ fontFamily: MI_FONTS.display, fontSize: '28px', fontWeight: 500, color: MI_COLORS.indigoDeep, marginBottom: '12px', letterSpacing: '-0.01em' }}>
      {title}
    </h3>
    {sub && <p style={{ fontFamily: MI_FONTS.body, fontSize: '15px', color: MI_COLORS.graphiteSoft, marginBottom: '24px' }}>{sub}</p>}
    <Link
      to={to}
      data-testid={testid}
      style={{ backgroundColor: MI_COLORS.copper, color: '#fff', fontFamily: MI_FONTS.body, fontSize: '15px', fontWeight: 500 }}
      className="px-7 py-3.5 rounded-full inline-flex items-center gap-2 hover:opacity-90 transition-opacity"
    >
      {label} <span aria-hidden>→</span>
    </Link>
  </div>
);
