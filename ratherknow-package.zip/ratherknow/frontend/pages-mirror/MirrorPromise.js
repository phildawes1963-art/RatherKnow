import { Link } from 'react-router-dom';
import MirrorShell from './MirrorShell';

const PROMISES = [
  {
    title: 'Every promise is about you.',
    body: 'We cannot find you love. Nobody can. No output here will ever predict another person’s behaviour, promise a meeting, or put a date on anything. We make promises about the one person we can honestly make them about: you.',
  },
  {
    title: 'Free to start.',
    body: 'Free. No card required. And not a trial — nothing expires, nothing converts, nothing quietly becomes a subscription while you’re not looking.',
  },
  {
    title: 'It ends.',
    body: 'Anything paid runs three months, then it stops. No renewal, nothing to cancel. The practice is finite and completable — it is designed to be finished and left, not to retain you.',
  },
  {
    title: 'A ceiling, in writing.',
    body: 'There is a maximum price here — one ceiling for the whole practice, and it will be published on this page before anything is purchasable. That is a standing public commitment, not a price point: once the figure is up, raising it would be a reputational event, and we know it.',
  },
  {
    title: 'No urgency.',
    body: 'No countdowns, no scarcity, no places-are-limited, no time-limited pricing. A decision made under pressure isn’t a decision — it’s a capture. Everything here will still be here tomorrow.',
  },
  {
    title: 'No upsell.',
    body: 'No inner circle, no mastermind, no next level. And nobody here will phone you.',
  },
  {
    title: 'No number we cannot justify.',
    body: 'No compatibility percentages. No banded scores before norms exist to justify them. Every instrument publishes its evidence tier in full — including the word “developmental” where it applies to our own.',
  },
];

const REFUSALS = [
  'A promise about another person',
  'A timeline or an outcome',
  'An unjustifiable number',
  'A clinical label — of you, or of anyone you describe',
  'A treatment claim',
  'A shame construction',
  'Urgency or scarcity',
  'An unsubstantiated superlative',
  '“Validated”, applied to a developmental instrument',
  'A verdict on anyone who hasn’t taken the assessment',
];

export default function MirrorPromise() {
  return (
    <MirrorShell title="The promise" description="Seven promises and ten refusals, published in full.">
      <div className="max-w-3xl mx-auto px-5 sm:px-8 py-14 sm:py-20">
        <p className="text-xs uppercase tracking-[0.18em] text-[#6E6E66]">The Mirror — manifesto</p>
        <h1 className="mi2-serif mt-3 text-4xl sm:text-5xl text-[#1C1C18]" data-testid="promise-title">
          The promise.
        </h1>
        <p className="mt-6 mi2-serif text-xl sm:text-2xl text-[#1C1C18] leading-snug max-w-2xl" data-testid="promise-opening">
          We cannot find you love. Nobody can. Every promise we make is about you, because that’s the only person we
          can honestly make one about.
        </p>
        <p className="mt-5 text-base text-[#3B3B34] leading-relaxed max-w-2xl">
          This page is the whole deal, in writing. We would rather say less and be able to prove it — so everything
          below is either checkable by using the product, or a standing commitment you can hold us to.
        </p>

        <section className="mt-12 space-y-5" data-testid="promise-list">
          {PROMISES.map((p, i) => (
            <div key={i} data-testid={`promise-item-${i + 1}`} className="bg-white border border-[#E4E4DE] p-6 sm:p-7 flex gap-5">
              <span className="mi2-serif text-2xl text-[#C8AE93] leading-none pt-0.5">{String(i + 1).padStart(2, '0')}</span>
              <div>
                <h2 className="mi2-serif text-xl text-[#1C1C18]">{p.title}</h2>
                <p className="mt-2 text-sm text-[#3B3B34] leading-relaxed">{p.body}</p>
              </div>
            </div>
          ))}
        </section>

        <section className="mt-14 bg-[#1C1C18] text-[#F6F6F2] p-8 sm:p-10" data-testid="promise-refusals">
          <h2 className="mi2-serif text-2xl sm:text-3xl">The refusals.</h2>
          <p className="mt-4 text-sm text-[#F6F6F2]/75 leading-relaxed max-w-xl">
            Ten classes of claim that are banned outright — in our copy, in anything machine-written, and in every
            partner’s promotion. Any output containing one of these is rejected, whoever wrote it.
          </p>
          <ul className="mt-6 grid gap-x-8 gap-y-3 sm:grid-cols-2 text-sm text-[#F6F6F2]/90">
            {REFUSALS.map((r, i) => (
              <li key={i} className="flex gap-3" data-testid={`promise-refusal-${i + 1}`}>
                <span className="text-[#7E8E77]">—</span> {r}
              </li>
            ))}
          </ul>
        </section>

        <section className="mt-12 space-y-4 text-sm text-[#3B3B34] leading-relaxed max-w-2xl" data-testid="promise-close">
          <p>
            Two more, behind the scenes. Your data is never sold, never shared, and never used to train any model —
            contractually, not aspirationally. And anything machine-written is disclosed, plainly, where it appears.
          </p>
          <p>
            It’s a self-reflection instrument, not a clinical tool. It informs conversations; it does not replace
            professionals.
          </p>
          <p>
            And if you’re ever afraid of someone, that isn’t a pattern to work on —{' '}
            <Link to="/mirror/safety" className="underline underline-offset-4" data-testid="promise-safety-link">
              here’s where to go instead
            </Link>.
          </p>
        </section>

        <div className="mt-12 flex flex-wrap items-center gap-5">
          <Link to="/mirror/take/essential" data-testid="promise-cta" className="bg-[#1C1C18] text-[#F6F6F2] px-6 py-3 rounded-sm text-sm hover:opacity-85">
            Hold us to it — start free
          </Link>
          <Link to="/mirror/methodology" className="text-sm underline underline-offset-4 text-[#3B3B34] hover:text-[#1C1C18]">
            The methodology behind it →
          </Link>
        </div>
      </div>
    </MirrorShell>
  );
}
