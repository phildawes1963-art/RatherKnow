import { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import MirrorShell from './MirrorShell';
import FindingsTeaser from './FindingsTeaser';
import { API } from './mirrorTheme';
import ClosenessResult from './results/ClosenessResult';
import EssentialResult from './results/EssentialResult';
import PersonalityResult from './results/PersonalityResult';
import EqResult from './results/EqResult';

const VIEWS = {
  'MI-AS-36': ClosenessResult,
  essential: EssentialResult,
  personality: PersonalityResult,
  eq: EqResult,
};

const TITLES = {
  'MI-AS-36': 'Closeness Mirror — your result',
  essential: 'Essential Mirror — your result',
  personality: 'Personality Mirror — your result',
  eq: 'EI Mirror — your result',
};

export default function MirrorResults() {
  const { sessionId } = useParams();
  const [result, setResult] = useState(null);
  const [error, setError] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const res = await fetch(`${API}/api/v2/assessments/${sessionId}/result`);
        if (!res.ok) throw new Error();
        setResult(await res.json());
      } catch {
        setError(true);
      }
    })();
  }, [sessionId]);

  if (error) {
    return (
      <MirrorShell title="Result not found">
        <div className="max-w-2xl mx-auto px-5 py-24 text-center" data-testid="results-error">
          <p className="text-[#3B3B34]">We couldn’t find that result. It may not be complete yet.</p>
          <Link className="underline underline-offset-4 mt-4 inline-block" to="/mirror">Back to The Mirror</Link>
        </div>
      </MirrorShell>
    );
  }

  if (!result) {
    return (
      <MirrorShell title="Your result">
        <div className="max-w-2xl mx-auto px-5 py-24 text-[#6E6E66]" data-testid="results-loading">Reading your result…</div>
      </MirrorShell>
    );
  }

  const View = VIEWS[result.instrument];
  const currentKey = result.instrument === 'MI-AS-36' ? 'closeness' : result.instrument;
  return (
    <MirrorShell title={TITLES[result.instrument] || 'Your result'}>
      <div className="max-w-3xl mx-auto px-5 sm:px-8 py-14 sm:py-20" data-testid="results-page">
        <View result={result} />
        <FindingsTeaser current={currentKey} />
      </div>
    </MirrorShell>
  );
}
