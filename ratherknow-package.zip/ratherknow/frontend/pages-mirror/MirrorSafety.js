import MirrorShell from './MirrorShell';

const ROUTES = [
  {
    name: 'In immediate danger',
    detail: 'Call 999.',
    contact: '999',
  },
  {
    name: 'National Domestic Abuse Helpline (Refuge)',
    detail: 'Free, confidential, 24 hours a day. For women; they will help anyone find the right service.',
    contact: '0808 2000 247',
    link: 'https://www.nationaldahelpline.org.uk',
  },
  {
    name: 'Respect Men’s Advice Line',
    detail: 'Confidential support for men experiencing domestic abuse.',
    contact: '0808 8010 327',
    link: 'https://mensadviceline.org.uk',
  },
  {
    name: 'Galop',
    detail: 'Support for LGBT+ people experiencing abuse or violence.',
    contact: '0800 999 5428',
    link: 'https://galop.org.uk',
  },
  {
    name: 'Samaritans',
    detail: 'Whatever you’re carrying, any hour, any day.',
    contact: '116 123',
    link: 'https://www.samaritans.org',
  },
];

export default function MirrorSafety() {
  return (
    <MirrorShell title="Safety" description="If you're afraid of someone, that isn't a pattern to work on. Here's where to go.">
      <div className="max-w-2xl mx-auto px-5 sm:px-8 py-14 sm:py-20">
        <p className="text-xs uppercase tracking-[0.18em] text-[#6E6E66]">Safety</p>
        <h1 className="mi2-serif mt-3 text-3xl sm:text-4xl leading-tight text-[#1C1C18]" data-testid="safety-title">
          If you’re ever afraid of someone, that isn’t a pattern to work on.
        </h1>

        <div className="mt-7 space-y-4 text-base text-[#3B3B34] leading-relaxed">
          <p>
            Everything on this site is about patterns — noticing them, measuring them, deciding what to do with them.
            One category is exempt from all of that, and it matters that we say so plainly.
          </p>
          <p>
            Control, coercion, monitoring, isolation, and fear of a specific person are not flags to weigh, not
            material for reflection, and not something any instrument here should be used on. They are a different
            category with a different answer, and the answer is support from people whose job this is.
          </p>
          <p className="mi2-serif text-lg text-[#1C1C18]">
            Fear of a specific person is always information — and never something to talk yourself out of.
          </p>
        </div>

        <div className="mt-10 space-y-4" data-testid="safety-routes">
          {ROUTES.map((r) => (
            <div key={r.name} className="bg-white border border-[#E4E4DE] px-6 py-5">
              <div className="flex flex-wrap items-baseline justify-between gap-2">
                <p className="text-base font-medium text-[#1C1C18]">{r.name}</p>
                <p className="text-base text-[#5B7284] font-medium">{r.contact}</p>
              </div>
              <p className="mt-1.5 text-sm text-[#6E6E66] leading-relaxed">{r.detail}</p>
              {r.link && (
                <a href={r.link} target="_blank" rel="noreferrer" className="mt-2 inline-block text-sm underline underline-offset-4 text-[#3B3B34] hover:text-[#1C1C18]">
                  {r.link.replace('https://', '')}
                </a>
              )}
            </div>
          ))}
        </div>

        <p className="mt-8 text-sm text-[#6E6E66] leading-relaxed">
          Outside the UK, the equivalent services in your country are the right first step — most countries run a
          national domestic abuse line and a crisis line. Nothing on this site is a substitute for them, and nothing
          you read here should ever be a reason to stay somewhere you’re afraid.
        </p>
      </div>
    </MirrorShell>
  );
}
