import { useState, useEffect, useRef, useCallback } from 'react';
import { Link } from 'react-router-dom';
import MirrorShell from './MirrorShell';
import { API, readReflections, saveReflection, clearReflection } from './mirrorTheme';

const PATTERN_COPY = {
  reprice: {
    title: 'You see it early, and you let it count.',
    body: "On your own account, when something has felt off you've tended to notice it at the time and let it change how you read what came next. That's a noticing pattern that works. The risk for you isn't blindness — it's the opposite: letting a single observation become a verdict before it's a pattern. One instance is human; repetition is information.",
    position: 'Your work mostly lives at Reflect: pattern or incident? Does it recur? You can afford to ask, because you don’t lose the observation by waiting.',
  },
  explain: {
    title: 'You see it early — and find a reason it’s fine.',
    body: "On your own account, the noticing itself works: things registered at the time. What happened next is the interesting part — the observation got explained, softened, or priced back down. That isn't foolishness; it's what investment does. Seeing clearly and letting it count are different skills, and the second one is buildable.",
    position: 'Your work sits between Notice and Reflect: keeping the observation alive long enough to check whether it repeats. Not as a verdict — as a record. An observation written down is much harder to renegotiate.',
  },
  late: {
    title: 'It tends to arrive in hindsight.',
    body: "On your own account, the pattern mostly became visible afterwards, looking back. Two things are true about that. Slow-arriving things are genuinely hard to see from inside — they arrive gradually, dressed as something good, while you're invested. And hindsight isn't failure; it's data about where your attention wasn't pointed.",
    position: 'Your work starts at Notice: logging what you observe in real time, without needing it to mean anything yet. Noticing without conclusion is the whole first stage — the rest can wait.',
  },
  mixed: {
    title: 'Your noticing changes with the situation.',
    body: "No single pattern dominated your answers — by your own account, sometimes things counted early, sometimes they got explained away or only arrived in hindsight. That's common, and it usually means the noticing depends on how invested you are. Which is itself worth knowing.",
    position: 'Your work spans Notice and Reflect: observe in real time, then check honestly whether the observation survives your own investment.',
  },
  insufficient: {
    title: 'Not much to reflect back — and that’s an honest result.',
    body: "Most of your answers said these situations haven't come up, or aren't recallable. We won't invent a pattern out of thin data — that would be a horoscope, and you were promised otherwise. If more of your history surfaces later, this takes three minutes to do again.",
    position: 'If and when something does register, the framework below is the shape of what to do with it — starting with Notice: observation without conclusion.',
  },
};

const STAGES = [
  ['Notice', 'observe the behaviour, without conclusion'],
  ['Reflect', 'is this a pattern or an incident? does it recur?'],
  ['Engage', "raise it, if it's worth raising"],
  ['Decide', 'and only then'],
];

const InlineRoutes = () => (
  <p className="text-sm leading-relaxed" data-testid="flag-inline-routes">
    National Domestic Abuse Helpline <strong>0808 2000 247</strong> (24/7, free) · Men’s Advice Line{' '}
    <strong>0808 8010 327</strong> · In danger now: <strong>999</strong> ·{' '}
    <Link to="/mirror/safety" className="underline underline-offset-4">the full safety page</Link>
  </p>
);

const SafetySplit = () => (
  <div className="border border-[#E4E4DE] bg-white px-5 py-4 text-[#3B3B34]" data-testid="flag-safety-split">
    <p className="text-sm leading-relaxed">
      <strong>One category is exempt from everything below.</strong> Control, coercion, monitoring, isolation, and fear
      of a specific person are not material for reflection. If that’s where you are, this isn’t the page —{' '}
      <Link to="/mirror/safety" className="underline underline-offset-4">this one is</Link>.
    </p>
  </div>
);

export default function MirrorFlagCheck() {
  const [phase, setPhase] = useState('loading'); // loading | intro | run | result | error
  const [payload, setPayload] = useState(null);
  const [answers, setAnswers] = useState({});
  const [idx, setIdx] = useState(0);
  const [result, setResult] = useState(null);
  const busy = useRef(false);

  const allItems = payload ? [...payload.items, payload.safety_item] : [];

  useEffect(() => {
    (async () => {
      const existing = readReflections().flag_check;
      if (existing) {
        try {
          const res = await fetch(`${API}/api/v2/reflections/${existing}`);
          if (res.ok) {
            const data = await res.json();
            setPayload(data);
            setAnswers(data.responses || {});
            if (data.status === 'complete' && data.result) {
              setResult(data.result);
              setPhase('result');
            } else {
              setPhase('intro');
            }
            return;
          }
          clearReflection('flag_check');
        } catch { /* fresh */ }
      }
      setPhase('intro');
    })();
  }, []);

  const begin = async () => {
    if (payload) {
      const first = allItems.findIndex((it) => answers[it.id] == null);
      setIdx(first === -1 ? 0 : first);
      setPhase('run');
      return;
    }
    try {
      const res = await fetch(`${API}/api/v2/reflections`, { method: 'POST' });
      const data = await res.json();
      saveReflection('flag_check', data.reflection_id);
      setPayload(data);
      setAnswers({});
      setIdx(0);
      setPhase('run');
    } catch {
      setPhase('error');
    }
  };

  const finish = useCallback(async (finalAnswers, reflectionId) => {
    if (busy.current) return;
    busy.current = true;
    try {
      const res = await fetch(`${API}/api/v2/reflections/${reflectionId}/complete`, { method: 'POST' });
      const data = await res.json();
      setResult(data);
      setPhase('result');
      window.scrollTo(0, 0);
    } catch {
      setPhase('error');
    } finally {
      busy.current = false;
    }
  }, []);

  const select = (value) => {
    const item = allItems[idx];
    const next = { ...answers, [item.id]: value };
    setAnswers(next);
    fetch(`${API}/api/v2/reflections/${payload.reflection_id}/responses`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ responses: [{ item_id: item.id, value }] }),
    }).catch(() => {});
    setTimeout(() => {
      if (idx + 1 >= allItems.length) finish(next, payload.reflection_id);
      else setIdx(idx + 1);
    }, 200);
  };

  // ---------- Result ----------
  if (phase === 'result' && result) {
    const copy = PATTERN_COPY[result.pattern] || PATTERN_COPY.insufficient;
    return (
      <MirrorShell title="Flag Check — your reflection" description="A reflection, not a measure.">
        <div className="max-w-2xl mx-auto px-5 sm:px-8 py-14 sm:py-20 space-y-10">
          <header>
            <p className="text-xs uppercase tracking-[0.18em] text-[#6E6E66]" data-testid="flag-result-label">
              Flag Check · A reflection, not a measure
            </p>
            <h1 className="mi2-serif mt-3 text-3xl sm:text-4xl text-[#1C1C18]" data-testid="flag-result-title">
              {copy.title}
            </h1>
          </header>

          {/* Safety before anything else (FR-N5) */}
          {result.safety === 'yes' ? (
            <section className="bg-[#1C1C18] text-[#F6F6F2] p-7 sm:p-8" data-testid="flag-safety-yes">
              <p className="mi2-serif text-xl leading-snug">
                You said part of this is about someone you’re afraid of. Then set the reflection aside — it isn’t the point.
              </p>
              <p className="mt-4 text-sm leading-relaxed text-[#F6F6F2]/85">
                Fear of a specific person is always information — and never something to talk yourself out of. Nothing
                on this page is a reason to stay anywhere you’re afraid, and working on your “noticing” is not the
                assignment. The right next step is people whose job this is:
              </p>
              <div className="mt-4 text-[#F6F6F2]/90"><InlineRoutes /></div>
            </section>
          ) : result.safety === 'unsure' ? (
            <section className="border border-[#C8AE93] bg-[#C8AE93]/10 px-6 py-5 text-[#3B3B34]" data-testid="flag-safety-unsure">
              <p className="text-sm leading-relaxed">
                You weren’t sure whether some of this is about someone you’re afraid of. That uncertainty deserves
                respect rather than analysis — if any part of you is checking, the checking itself is worth taking
                seriously. Fear of a specific person is always information.
              </p>
              <div className="mt-3"><InlineRoutes /></div>
            </section>
          ) : (
            <SafetySplit />
          )}

          <section data-testid="flag-profile">
            <p className="text-base text-[#3B3B34] leading-relaxed">{copy.body}</p>
          </section>

          <section className="bg-white border border-[#E4E4DE] p-7" data-testid="flag-graduated">
            <p className="text-xs uppercase tracking-[0.14em] text-[#6E6E66]">The graduated response</p>
            <div className="mt-4 grid gap-3 sm:grid-cols-4">
              {STAGES.map(([name, desc], i) => (
                <div key={name} className="border-t-2 border-[#7E8E77] pt-2">
                  <p className="text-sm font-medium text-[#1C1C18]">{i + 1}. {name}</p>
                  <p className="mt-1 text-xs text-[#6E6E66] leading-relaxed">{desc}</p>
                </div>
              ))}
            </div>
            <p className="mt-5 text-sm text-[#3B3B34] leading-relaxed">{copy.position}</p>
            <p className="mt-4 text-xs text-[#6E6E66] leading-relaxed border-t border-[#E4E4DE] pt-3">
              One category is exempt from graduation: anything involving fear, control or coercion is not a yellow flag
              to explore. It has a different answer, and it’s on <Link to="/mirror/safety" className="underline underline-offset-4">the safety page</Link>.
            </p>
          </section>

          <p className="text-xs text-[#6E6E66] leading-relaxed" data-testid="flag-disclosure">
            A reflection, not a measure. No score was produced, nothing was graded, and nothing here is a diagnosis —
            these questions never asked about anyone but you.
          </p>

          {/* One CTA only (FR-N7) */}
          <section className="border-t border-[#E4E4DE] pt-8">
            <p className="text-base text-[#3B3B34] leading-relaxed max-w-xl">
              The thing underneath the noticing — what you’re drawn to, what you excuse, and the gap between who you
              are and who you say you want — is measurable. That’s the Essential Mirror.
            </p>
            <Link
              to="/mirror/take/essential"
              data-testid="flag-cta-essential"
              className="mt-5 inline-block bg-[#1C1C18] text-[#F6F6F2] px-6 py-3 rounded-sm text-sm hover:opacity-85"
            >
              Take the Essential Mirror — free
            </Link>
          </section>
        </div>
      </MirrorShell>
    );
  }

  // ---------- Run ----------
  if (phase === 'run' && payload) {
    const item = allItems[idx];
    const isSafety = item.id === 'f-safety';
    const options = isSafety ? payload.safety_item.options : payload.options;
    return (
      <MirrorShell title="Flag Check" minimal>
        <div className="fixed top-0 left-0 right-0 z-30 h-[2px] bg-[#E4E4DE]">
          <div className="h-full bg-[#1C1C18] transition-[width] duration-300" style={{ width: `${(idx / allItems.length) * 100}%` }} />
        </div>
        <div className="min-h-screen flex flex-col px-5 sm:px-8">
          <div className="max-w-2xl w-full mx-auto pt-10 flex items-center justify-between text-xs text-[#6E6E66]">
            <span className="uppercase tracking-[0.14em]">Flag Check · a reflection, not a measure</span>
            <span data-testid="flag-progress">{idx + 1} of {allItems.length}</span>
          </div>
          <div className="flex-1 flex items-center">
            <div className="max-w-2xl w-full mx-auto py-10" key={item.id}>
              {!isSafety && (
                <p className="mi2-fade text-xs uppercase tracking-[0.14em] text-[#6E6E66] mb-4">
                  Have you been somewhere like this?
                </p>
              )}
              <p className="mi2-fade text-xl sm:text-2xl leading-relaxed text-[#1C1C18]" data-testid="flag-item-statement">
                {item.text}
              </p>
              <div className="mi2-fade mt-8 grid gap-2" role="radiogroup">
                {options.map((label, i) => {
                  const value = i + 1;
                  const isSel = answers[item.id] === value;
                  return (
                    <button
                      key={value}
                      role="radio"
                      aria-checked={isSel}
                      onClick={() => select(value)}
                      data-testid={`flag-option-${value}`}
                      className={`border px-5 py-3.5 text-left text-sm sm:text-base ${
                        isSel
                          ? 'bg-[#1C1C18] text-[#F6F6F2] border-[#1C1C18]'
                          : 'bg-white text-[#3B3B34] border-[#E4E4DE] hover:border-[#1C1C18] hover:bg-[#FBFBF9]'
                      }`}
                    >
                      {label}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
          <div className="max-w-2xl w-full mx-auto pb-10 text-sm">
            <button
              onClick={() => idx > 0 && setIdx(idx - 1)}
              disabled={idx === 0}
              data-testid="flag-back-btn"
              className="text-[#6E6E66] hover:text-[#1C1C18] disabled:opacity-30"
            >
              ← Back
            </button>
          </div>
        </div>
      </MirrorShell>
    );
  }

  // ---------- Intro ----------
  return (
    <MirrorShell title="Flag Check" description="It reads you, not them. A reflection, not a measure.">
      <div className="max-w-2xl mx-auto px-5 sm:px-8 py-16 sm:py-24">
        {phase === 'loading' ? (
          <p className="text-[#6E6E66]" data-testid="flag-loading">Preparing…</p>
        ) : phase === 'error' ? (
          <div data-testid="flag-error">
            <p className="text-[#3B3B34]">Something went wrong. Nothing is lost — try again.</p>
            <button onClick={() => window.location.reload()} className="mt-4 underline underline-offset-4">Reload</button>
          </div>
        ) : (
          <div className="mi2-fade space-y-7">
            <div>
              <p className="text-xs uppercase tracking-[0.18em] text-[#6E6E66]">A reflection, not a measure</p>
              <h1 className="mi2-serif mt-4 text-3xl sm:text-4xl text-[#1C1C18]" data-testid="flag-intro-title">
                The Flag Check.
              </h1>
              <p className="mt-2 text-base text-[#5B7284]">It reads you, not them.</p>
            </div>

            {/* Safety split above the fold (FR-N5) */}
            <SafetySplit />

            <div className="space-y-4 text-base text-[#3B3B34] leading-relaxed">
              <p>
                Eight situations people recognise. Not one of them asks you to rate, diagnose or describe another
                person — every question is about what <em>you</em> noticed, when, and what you did with it.
              </p>
              <p>
                There's no score at the end, no band, no grade. What you get back is a reflection of your own noticing
                pattern, and a framework for what to do with an observation that isn't “leave” and isn't “let it go”.
              </p>
            </div>
            <div className="border-t border-[#E4E4DE] pt-5 text-sm text-[#6E6E66] space-y-1.5">
              <p>9 questions · about 3 minutes · anonymous, no account</p>
              <p>Answer from your own history, across relationships — not about any one person.</p>
            </div>
            <div className="flex items-center gap-5">
              <button
                onClick={begin}
                data-testid="flag-start-btn"
                className="bg-[#1C1C18] text-[#F6F6F2] px-7 py-3 rounded-sm text-sm hover:opacity-85"
              >
                {payload && Object.keys(answers).length > 0 ? 'Continue where you left off' : 'Begin'}
              </button>
              <Link to="/mirror" className="text-sm text-[#6E6E66] hover:text-[#1C1C18]">Not now</Link>
            </div>
          </div>
        )}
      </div>
    </MirrorShell>
  );
}
