// Remaps old-site links inside Learn content to remodel routes.
const RULES = [
  [/^\/mirror-index\/learn\/(.+)$/, (m) => `/mirror/learn/${m[1]}`],
  [/^\/mirror-index\/archetypes(\/.*)?$/, () => '/mirror/take/essential'],
  [/^\/mirror-index\/how-it-works$/, () => '/mirror/methodology'],
  [/^\/mirror-index\/philosophy$/, () => '/mirror/methodology'],
  [/^\/mirror-index\/science$/, () => '/mirror/methodology'],
  [/^\/mirror-index\/for-business$/, () => '/mirror/methodology'],
  [/^\/mirror-index(\/.*)?$/, () => '/mirror'],
];

export function remapLink(path) {
  for (const [re, fn] of RULES) {
    const m = path.match(re);
    if (m) return fn(m);
  }
  return path;
}
