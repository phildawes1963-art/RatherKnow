import { useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import './mirror.css';

const NAV = [
  { to: '/mirror/promise', label: 'Promise' },
  { to: '/mirror/learn', label: 'Learn' },
  { to: '/mirror/methodology', label: 'Methodology' },
  { to: '/mirror/safety', label: 'Safety' },
  { to: '/mirror/mirrors', label: 'Your mirrors' },
];

export default function MirrorShell({ title, description, children, minimal = false }) {
  const { pathname } = useLocation();
  useEffect(() => {
    document.querySelectorAll('head [data-static-seo]').forEach((el) => el.remove());
  }, []);
  return (
    <div className="mi2 mi2-noise">
      <Helmet>
        <title>{title ? `${title} · The Mirror` : 'The Mirror — for people who’d rather know'}</title>
        {description && <meta name="description" content={description} />}
        <link rel="canonical" href={`https://mymirrorreport.com${pathname}`} />
      </Helmet>

      {!minimal && (
        <header className="sticky top-0 z-20 border-b border-[#E4E4DE] bg-[#F6F6F2]/95 backdrop-blur">
          <div className="max-w-6xl mx-auto px-5 sm:px-8 h-16 flex items-center justify-between">
            <Link to="/mirror" data-testid="mi2-nav-home" className="mi2-serif text-xl tracking-tight text-[#1C1C18]">
              The Mirror<span className="text-[#7E8E77]">.</span>
            </Link>
            <nav className="flex items-center gap-4 sm:gap-7">
              {NAV.map((n) => (
                <Link
                  key={n.to}
                  to={n.to}
                  data-testid={`mi2-nav-${n.label.toLowerCase().replace(/\s/g, '-')}`}
                  className="hidden sm:inline text-sm text-[#3B3B34] hover:text-[#1C1C18]"
                >
                  {n.label}
                </Link>
              ))}
              <Link
                to="/mirror/take/essential"
                data-testid="mi2-nav-start"
                className="text-sm bg-[#1C1C18] text-[#F6F6F2] px-4 py-2 rounded-sm hover:opacity-85"
              >
                Start free
              </Link>
            </nav>
          </div>
        </header>
      )}

      <main className="relative z-10">{children}</main>

      {!minimal && (
        <footer className="relative z-10 border-t border-[#E4E4DE] mt-24">
          <div className="max-w-6xl mx-auto px-5 sm:px-8 py-14 grid gap-10 sm:grid-cols-3">
            <div>
              <p className="mi2-serif text-lg text-[#1C1C18]">The Mirror.</p>
              <p className="mt-3 text-sm text-[#6E6E66] leading-relaxed max-w-xs">
                A relationship assessment for people who’d rather know than be reassured.
              </p>
              <p className="mt-4 text-xs text-[#6E6E66]">An independent study by My Mirror Report.</p>
            </div>
            <div>
              <p className="text-xs uppercase tracking-[0.1em] text-[#6E6E66] mb-3">The instruments</p>
              <ul className="space-y-2 text-sm">
                <li><Link className="text-[#3B3B34] hover:text-[#1C1C18]" to="/mirror/take/essential">Essential Mirror</Link></li>
                <li><Link className="text-[#3B3B34] hover:text-[#1C1C18]" to="/mirror/take/closeness">Closeness Mirror</Link></li>
                <li><Link className="text-[#3B3B34] hover:text-[#1C1C18]" to="/mirror/take/personality">Personality Mirror</Link></li>
                <li><Link className="text-[#3B3B34] hover:text-[#1C1C18]" to="/mirror/take/eq">EI Mirror</Link></li>
                <li><Link className="text-[#3B3B34] hover:text-[#1C1C18]" to="/mirror/flag-check">Flag Check — a reflection</Link></li>
                <li><Link className="text-[#3B3B34] hover:text-[#1C1C18]" to="/mirror/samples" data-testid="mi2-footer-samples">Sample results</Link></li>
                <li><Link className="text-[#3B3B34] hover:text-[#1C1C18]" to="/mirror/mirrors">Your mirrors</Link></li>
              </ul>
            </div>
            <div>
              <p className="text-xs uppercase tracking-[0.1em] text-[#6E6E66] mb-3">The honest bit</p>
              <p className="text-sm text-[#3B3B34] leading-relaxed">It can’t find you anyone. Nothing can.</p>
              <Link to="/mirror/promise" data-testid="mi2-footer-promise" className="mt-2 inline-block text-sm underline underline-offset-4 text-[#3B3B34] hover:text-[#1C1C18]">
                Read the promise in full
              </Link>
              <br />
              <Link to="/mirror/faq" data-testid="mi2-footer-faq" className="mt-2 inline-block text-sm underline underline-offset-4 text-[#3B3B34] hover:text-[#1C1C18]">
                Questions, answered
              </Link>
              <p className="mt-2 text-sm text-[#6E6E66] leading-relaxed">
                It’s a self-reflection instrument, not a clinical tool. It informs conversations; it does not replace
                professionals.
              </p>
              <Link to="/mirror/safety" data-testid="mi2-footer-safety" className="mt-3 inline-block text-sm underline underline-offset-4 text-[#3B3B34] hover:text-[#1C1C18]">
                If you’re afraid of someone, start here
              </Link>
            </div>
          </div>
        </footer>
      )}
    </div>
  );
}
