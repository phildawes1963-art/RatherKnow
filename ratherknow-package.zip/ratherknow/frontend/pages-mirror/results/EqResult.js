import { Link } from 'react-router-dom';
import { TIER_STATEMENTS } from '../mirrorTheme';

const Bar = ({ score }) => (
  <div className="h-2 bg-[#EDEDE8] w-full">
    <div className="h-full bg-[#5B7284]" style={{ width: `${(score / 5) * 100}%` }} />
  </div>
);

export default function EqResult({ result }) {
  const domains = Object.entries(result.domain_scores);

  return (
    <div className="space-y-12">
      <header>
        <p className="text-xs uppercase tracking-[0.18em] text-[#6E6E66]">EI Mirror · Goleman four domains</p>
        <h1 className="mi2-serif mt-3 text-3xl sm:text-4xl text-[#1C1C18]" data-testid="eq-title">
          How you handle what you feel.
        </h1>
        <p className="mt-4 text-sm text-[#3B3B34]" data-testid="eq-overall">
          Overall: <strong>{result.overall_score}</strong> of 5 — {result.overall_band}
        </p>
      </header>

      <section className="space-y-6" data-testid="eq-domains">
        {domains.map(([key, d]) => (
          <div key={key} className="bg-white border border-[#E4E4DE] p-6">
            <div className="flex items-baseline justify-between gap-4">
              <h2 className="mi2-serif text-xl text-[#1C1C18]">{d.name}</h2>
              <p className="text-sm text-[#5B7284] whitespace-nowrap">{d.score}/5 · {d.band}</p>
            </div>
            <div className="mt-3"><Bar score={d.score} /></div>
            <p className="mt-3 text-xs text-[#6E6E66] leading-relaxed">{d.description}</p>
            <div className="mt-4 grid gap-1.5 sm:grid-cols-2">
              {Object.values(result.sub_scores).filter((sSub) => sSub.domain === key).map((sSub) => (
                <p key={sSub.name} className="text-xs text-[#3B3B34] flex justify-between border-t border-[#E4E4DE] pt-1.5">
                  <span>{sSub.name}</span><span className="text-[#6E6E66]">{sSub.score} · {sSub.band}</span>
                </p>
              ))}
            </div>
          </div>
        ))}
      </section>

      <section className="grid gap-5 sm:grid-cols-2" data-testid="eq-strengths">
        <div className="bg-white border border-[#E4E4DE] p-6">
          <p className="text-xs uppercase tracking-[0.12em] text-[#7E8E77]">Leading with</p>
          <ul className="mt-3 space-y-2 text-sm text-[#3B3B34]">
            {result.strengths.map((st) => <li key={st.name}>{st.name} — {st.score}</li>)}
          </ul>
        </div>
        <div className="bg-white border border-[#E4E4DE] p-6">
          <p className="text-xs uppercase tracking-[0.12em] text-[#C8AE93]">Worth developing</p>
          <ul className="mt-3 space-y-2 text-sm text-[#3B3B34]">
            {result.growth_areas.map((g) => <li key={g.name}>{g.name} — {g.score}</li>)}
          </ul>
        </div>
      </section>

      <section className="border border-[#E4E4DE] bg-white p-6" data-testid="eq-evidence-tier">
        <p className="text-[11px] uppercase tracking-[0.1em] bg-[#1C1C18] text-[#F6F6F2] inline-block px-2 py-0.5">Established</p>
        <p className="mt-3 text-sm text-[#3B3B34] leading-relaxed">
          {TIER_STATEMENTS.eq} A self-report read of how you perceive your own capacities — informative, and honest
          about being a self-perception rather than an ability test.
        </p>
      </section>

      <section className="border-t border-[#E4E4DE] pt-8 flex flex-wrap items-center gap-5">
        <Link to="/mirror/mirrors" data-testid="eq-cta-mirrors" className="bg-[#1C1C18] text-[#F6F6F2] px-6 py-3 rounded-sm text-sm hover:opacity-85">
          See all your mirrors
        </Link>
        <Link to="/mirror/take/closeness" className="text-sm underline underline-offset-4 text-[#3B3B34] hover:text-[#1C1C18]">
          Next: the Closeness Mirror →
        </Link>
      </section>
    </div>
  );
}
