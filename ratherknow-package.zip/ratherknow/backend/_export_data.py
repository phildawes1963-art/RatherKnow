"""One-shot export run against the MM backend to freeze the data RK needs.
Run from /app/backend: python3 /app/migration/ratherknow/backend/_export_data.py
"""
import asyncio, json, os, sys
from datetime import datetime, timezone

sys.path.insert(0, "/app/backend")
from dotenv import load_dotenv
load_dotenv("/app/backend/.env")

OUT = os.path.dirname(os.path.abspath(__file__))


def export_essential():
    from routes.dating_wellness import (
        SELF_ASSESSMENT_QUESTIONS, IDEAL_PARTNER_QUESTIONS, ARCHETYPES, COMPATIBILITY_MATRIX,
    )

    def clean(o):
        if isinstance(o, dict):
            return {k: clean(v) for k, v in o.items()}
        if isinstance(o, (list, tuple, set)):
            return [clean(v) for v in o]
        return o

    data = {
        "self_assessment_questions": clean(SELF_ASSESSMENT_QUESTIONS),
        "ideal_partner_questions": clean(IDEAL_PARTNER_QUESTIONS),
        "archetypes": clean(ARCHETYPES),
        "compatibility_matrix": {"|".join(sorted(k)): clean(v) for k, v in COMPATIBILITY_MATRIX.items()},
    }
    with open(os.path.join(OUT, "constants", "essential_data.json"), "w") as fh:
        json.dump(data, fh, indent=1)
    print("essential_data.json:",
          len(data["self_assessment_questions"]), "self,",
          len(data["ideal_partner_questions"]), "ideal,",
          len(data["archetypes"]), "archetypes,",
          len(data["compatibility_matrix"]), "compat pairs")


async def export_norms():
    from routes.p150_norms import _get_config_doc, _bands_for
    from constants.p150_data import P150_FACTORS
    config = await _get_config_doc()
    snapshot = {
        "exported_at": datetime.now(timezone.utc).isoformat(),
        "source": "mymirrorreport backend effective bands (super-admin config over defaults)",
        "factors": {},
    }
    for key in P150_FACTORS:
        snapshot["factors"][key] = _bands_for(config, key)
    with open(os.path.join(OUT, "constants", "p150_norms_snapshot.json"), "w") as fh:
        json.dump(snapshot, fh, indent=1)
    custom = sum(1 for k in P150_FACTORS if (config.get("factors", {}).get(k) or {}).get("bands"))
    print(f"p150_norms_snapshot.json: {len(snapshot['factors'])} factors ({custom} custom, rest defaults)")


export_essential()
asyncio.run(export_norms())
