"""Parity check: the packaged RK scorers must match the live MM scorers digit-for-digit.
Runs each side in a subprocess with its own PYTHONPATH (module names collide otherwise).
"""
import json
import random
import subprocess
import sys

random.seed(42)
P150_RESPONSES = {str(i): random.randint(1, 5) for i in range(1, 131)}
ESSENTIAL_ANSWERS = [{"question_id": q, "answer": random.randint(1, 5)} for q in range(1, 51)]

LIVE = r"""
import asyncio, json, sys
sys.path.insert(0, "/app/backend")
from dotenv import load_dotenv; load_dotenv("/app/backend/.env")
responses = json.loads(sys.argv[1]); answers = json.loads(sys.argv[2])
from services.p150_scoring import score_p150_from_responses
s = asyncio.run(score_p150_from_responses(responses))
from routes.dating_wellness import QuizAnswer, calculate_archetype_scores, calculate_dimension_scores, get_compatibility_result
qa = [QuizAnswer(**a) for a in answers]
arch = calculate_archetype_scores(qa)
out = {
    "factors": {k: [v["raw_score"], v["sten"], v["label"]] for k, v in s["factor_scores"].items()},
    "globals": s["global_scores"], "validity": s["validity"],
    "strengths": s["strengths"], "blind_spots": s["blind_spots"],
    "arch": arch, "dims": calculate_dimension_scores(qa),
    "compat": get_compatibility_result(arch, "self_assessment"),
}
print(json.dumps(out, sort_keys=True, default=str))
"""

PACKAGED = r"""
import json, sys
sys.path.insert(0, "/app/migration/ratherknow/backend")
responses = json.loads(sys.argv[1]); answers = json.loads(sys.argv[2])
from services.p150_lite import score_p150_lite
s = score_p150_lite(responses)
from services.essential_scoring import QuizAnswer, calculate_archetype_scores, calculate_dimension_scores, get_compatibility_result
qa = [QuizAnswer(**a) for a in answers]
arch = calculate_archetype_scores(qa)
out = {
    "factors": {k: [v["raw_score"], v["sten"], v["label"]] for k, v in s["factor_scores"].items()},
    "globals": s["global_scores"], "validity": s["validity"],
    "strengths": s["strengths"], "blind_spots": s["blind_spots"],
    "arch": arch, "dims": calculate_dimension_scores(qa),
    "compat": get_compatibility_result(arch, "self_assessment"),
}
print(json.dumps(out, sort_keys=True, default=str))
"""


def run(code):
    r = subprocess.run([sys.executable, "-c", code, json.dumps(P150_RESPONSES), json.dumps(ESSENTIAL_ANSWERS)],
                       capture_output=True, text=True, timeout=120)
    if r.returncode != 0:
        print(r.stderr[-3000:])
        sys.exit(1)
    return json.loads(r.stdout.strip().splitlines()[-1])


live = run(LIVE)
pkg = run(PACKAGED)
ok = True
for key in live:
    if live[key] != pkg[key]:
        ok = False
        print(f"MISMATCH in {key}:\n  live={json.dumps(live[key])[:400]}\n  pkg ={json.dumps(pkg[key])[:400]}")
if ok:
    print("PARITY OK — factors/globals/validity/strengths/blind_spots + archetypes/dimensions/compatibility all identical")
sys.exit(0 if ok else 1)
